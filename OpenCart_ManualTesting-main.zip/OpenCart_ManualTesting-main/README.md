# 🛒 OpenCart E-Commerce — Manual Testing Project

End-to-end manual QA project for the OpenCart e-commerce platform. Built independently to demonstrate practical, job-ready manual testing skills covering the complete QA lifecycle — from test planning to defect reporting.

---

## 🎯 Project Objective

To simulate a real-world QA engagement by designing comprehensive manual test cases across major e-commerce workflows, identifying and documenting defects with proper severity classification, and producing professional QA documentation.

**Application Under Test:** [OpenCart Demo](https://demo.opencart.com/)
**Testing Type:** Manual Testing
**Tester:** Kavya K B — QA Engineer | 1+ year professional experience

---

## 📊 Testing Summary

| Metric | Count |
|--------|-------|
| Total Test Cases Written | 182 |
| Total Bugs Reported | 10 |
| Critical Bugs | 5 |
| Major Bugs | 3 |
| Minor Bugs | 1 |
| Trivial/Info | 1 |

---

## 📁 Repository Contents

| File | Description |
|------|-------------|
| `OpenCart_Test Plan.docx` | Scope, objectives, entry/exit criteria, risk analysis |
| `OpenCart_TestScenarios.xlsx` | High-level test scenarios for all modules |
| `OpenCart_TestCases.xlsx` | 182 detailed test cases with steps, expected vs actual results |
| `OpenCart_TestExecution_Result.xlsx` | Test execution results with pass/fail status |
| `OpenCart_RTM.xlsx` | Requirements Traceability Matrix mapping features to test cases |
| `OpenCart_BugReport.xlsx` | 10 bugs documented with severity, priority, and reproduction steps |

---

## 🧪 Modules Tested

| Module | Test Focus |
|--------|-----------|
| Login | Valid/invalid login, session handling |
| Register | New user registration, field validations |
| Forgot Password | Recovery flow, error handling |
| Logout | Session management, redirection |
| Search | Product search, filters, edge cases |
| Product Display | Product details, images, pricing |
| Add to Cart | Cart operations, quantity changes |
| Wishlist | Wishlist add/remove, constraints |
| Checkout | Billing, shipping, order confirmation |

---

## ✅ Test Case Format

| Field | Description |
|-------|-------------|
| Test Scenario ID | High-level scenario reference |
| Test Case ID | Unique test case identifier |
| Description | What is being tested |
| Precondition | Required state before test |
| Test Steps | Step-by-step execution guide |
| Test Data | Input values used |
| Expected Result | What should happen |
| Actual Result | What actually happened |
| Status | Pass / Fail |
| Severity | Critical / Major / Minor / Trivial |

---

## 🛠️ Tools Used

- **Microsoft Excel** — Test case design and documentation
- **OpenCart Demo Environment** — Web application under test
- **GitHub** — Version control and project showcase

---

## 🧠 Testing Techniques Applied

- Equivalence Partitioning
- Boundary Value Analysis
- Decision Table Testing
- Error Guessing
- Exploratory Testing

---

## 💡 Key Learnings

- Designed test cases independently simulating real QA workflows
- Applied proper severity and priority classification for defect reporting
- Maintained full traceability between requirements and test cases via RTM
- Documented test execution results in a format ready for stakeholder review

---

## 🚀 What's Next

- Automate critical user flows (Login, Register, Checkout) using Selenium WebDriver + Java + TestNG
- Add Postman API test cases for OpenCart REST endpoints
- Integrate with Jenkins CI/CD for continuous test execution

---

## 👩‍💻 About Me

I'm **Kavya K B**, a QA Engineer with 1+ year of professional experience in Manual and Automation Testing at Indusface (Cybersecurity WAF) and BrightCHAMPS (EdTech LMS).

---

## 📬 Connect

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=flat&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/kavyakb58)
[![GitHub](https://img.shields.io/badge/GitHub-181717?style=flat&logo=github&logoColor=white)](https://github.com/Kavyakb58)
[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=flat&logo=gmail&logoColor=white)](mailto:kavyakb58@gmail.com)

---

⭐ If you found this project helpful, feel free to star the repo!
